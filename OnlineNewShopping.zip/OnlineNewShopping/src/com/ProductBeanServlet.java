package com;

import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ProductBean;


/**
 * Servlet implementation class ProductBeanServlet
 */
public class ProductBeanServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<ProductBean> pl = new ArrayList<ProductBean>();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductBeanServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int PID = Integer.parseInt(request.getParameter("PID"));
		System.out.println(request.getParameter("PNAME"));
		
		//select product details using PID
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			

			String select_query="select * from products where product_id= "+PID;
			System.out.println(select_query);
	        java.sql.Statement s = conn.createStatement();
	        ResultSet rs = s.executeQuery(select_query);
	        
	        // pl = ArrayList<ProductBean>;
	        
	        ProductBean pb = new ProductBean();
	        
	        while(rs.next()){
	        /*pb.setProduct_id(rs.getInt(1));
	        pb.setProduct_name(rs.getString(2));
	        pb.setProduct_price(rs.getInt(3));*/
	        
	        pl.add(new ProductBean(rs.getInt(1),rs.getString(2),rs.getInt(3)));
	        }
	        
	        for(ProductBean ps:pl){
	        System.out.println(ps);
	        }
	        HttpSession session = request.getSession();
	        session.setAttribute("list", pl); 
	        
	        

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
		RequestDispatcher rd = request.getRequestDispatcher("viewproducts.jsp");
 		rd.forward(request,response);
               
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
	}

}
