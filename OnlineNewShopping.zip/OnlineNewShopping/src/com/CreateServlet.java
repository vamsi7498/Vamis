package com;

 

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

 

 

 

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Connection;

/**
 * Servlet implementation class CreateServlet
 */
public class CreateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }



    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        //response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        //doGet(request, response);
        
        try{
            String fname = request.getParameter("first_name");
            String lname = request.getParameter("last_name");
            String username = request.getParameter("mail");
            long mobile =Long.parseLong(request.getParameter("contact"));
            int age=Integer.parseInt(request.getParameter("age"));
            String gender=request.getParameter("gender");
            String dob = request.getParameter("dob");
            String password=request.getParameter("password");
            String confirmpassword =request.getParameter("confirmpassword");
            


            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
            System.out.println("connected");
            PreparedStatement ps= conn.prepareStatement("insert into shopping values(?,?,?,?,?,?,?,?)");
        
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, username);
            ps.setLong(4, mobile);
            ps.setString(5, gender);
            ps.setInt(6, age);
            ps.setString(7, dob);
            ps.setString(8, password);

           
            if(password.equals(confirmpassword)){
                System.out.println("in if execute");
            int result=ps.executeUpdate();
                 if(result>0){
                     String username1 = request.getParameter("mail");
                     HttpSession session = request.getSession();
                     session.setAttribute("username",username1);
                     System.out.println("Inserted");
                     RequestDispatcher rd = request.getRequestDispatcher("After.html");
                     rd.forward(request,response);
                }
        }
            else{
                PrintWriter pw = response.getWriter();
                pw.print("please enter same password");
                RequestDispatcher rd = request.getRequestDispatcher("create.html");
                 rd.forward(request,response);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
       
    }
}