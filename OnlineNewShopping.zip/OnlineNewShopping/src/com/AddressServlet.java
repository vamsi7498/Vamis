package com;

 

 

 

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

 

 

 

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

 

 

 

/**
 * Servlet implementation class AddressServlet
 */
public class AddressServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddressServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

 

 

 

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        //response.getWriter().append("Served at: ").append(request.getContextPath());
        try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
        System.out.println("connected");
        PreparedStatement ps= conn.prepareStatement("insert into address(username) values(?)");
        
        HttpSession session = request.getSession();
        String username = (String)session.getAttribute("username");
        
        ps.setString(1, username);
        
        System.out.println("after html session");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }

 

 

 

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        //doGet(request, response);
        try{
            String country = request.getParameter("country");
            String state = request.getParameter("state");
            String district  = request.getParameter("district");
            String city =request.getParameter("city");
            String doorno = request.getParameter("doorno");
            String addr=request.getParameter("addr");
            String land=request.getParameter("land");
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
            System.out.println("connected");
            PreparedStatement ps= conn.prepareStatement("insert into address (country,state,district,city,doorno,addr,landmark) values(?,?,?,?,?,?,?)");
            
            ps.setString(1, country);
            ps.setString(2, state);
            ps.setString(3, district);
            ps.setString(4, city);
            ps.setString(5, doorno);
            ps.setString(6, addr);
            ps.setString(7,land);
            
            
            
            HttpSession sess = request.getSession();
            sess.setAttribute("country", country);
            sess.setAttribute("state", state);
            sess.setAttribute("district", district);
            sess.setAttribute("city", city);
            sess.setAttribute("doorno", doorno);
            sess.setAttribute("addr", addr);
            sess.setAttribute("land", land);
                        
            if(country != ""|| state != ""|| district != ""|| city != ""|| doorno != ""|| addr != ""){
                int result=ps.executeUpdate();
                System.out.println("Address Inserted");
                response.sendRedirect("payments.jsp");
            }
            else{
                response.sendRedirect("address.html");
                System.out.println("Address Not Inserted");
            }
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    
    }

 

 

 

}